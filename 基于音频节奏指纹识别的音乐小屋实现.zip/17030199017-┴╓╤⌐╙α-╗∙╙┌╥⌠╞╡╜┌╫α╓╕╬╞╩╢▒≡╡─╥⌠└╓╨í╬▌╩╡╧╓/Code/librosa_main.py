# -*- coding: utf-8 -*-

from dtw import dtw
from numpy.linalg import norm
from numpy import array
import numpy as np
import librosa
import pyaudio
import wave
import time

def act(song):
    if song == 'Wind.wav':
        print('Turning on the electric fan, please wait a while.')
        time.sleep(2)
        print('Now the fan is turned on!')
    elif song == 'Time.wav':
        print('The time now is: ',time.strftime('%Y-%m-%d %H:%M:%S'))
    elif song == 'BoleroOfFire.wav':
        print('Turning on the daylight, please wait a while.')
        time.sleep(1)
        print('Now the daylight is turned on!')
    elif song == 'Forest.wav':
        print('Turning on the watering machine, please wait a while.')
        time.sleep(3)
        print('Now water the plants.')
    elif song == 'LostWoods.wav':
        print('Saria Phone Finder is calling your phone, please wait a while.')
        time.sleep(2)
        print('My phone: A phone from Saria Phone Finder. I am here!')
    elif song == 'SongofHealing.wav':
        print('reseting modules to Previous, please wait a while.')
        time.sleep(4)
        print('All modules have been Previous!')
    else:
        print("No matching song!")
    
    print('------------------------------')


while True:
    filename = input('------------------------------------------------\nPlay the song(input quit to break the program):)\n')
    start = time.time()    
    if(filename == 'quit'):
        break
    all_data = np.load('beatDatabase.npy')
    beat_database = all_data.item()#[('music_base\\Forest.wav',array([25.96666667, 25.96666667,...),(),()]

    testAudio = "music_test/" + filename
    try:
        y, sr = librosa.load(testAudio)
    except Exception:
        print("Wrong musicname, Please try again!")
        continue
        
    tempo, beat_frames = librosa.beat.beat_track(y=y, sr=sr)
    beat_frames = librosa.feature.delta(beat_frames)


    x = array(beat_frames).reshape(-1, 1)#未知歌曲的beat_frames,一列n行
    compare_result = {}
    for songID in beat_database.keys():
        y = beat_database[songID]#数据库中的beat_frames,array([25.96666667, 25.96666667,...)
        y = array(y).reshape(-1, 1)
        dist, cost, acc, path = dtw(x, y, dist=lambda x, y: norm(x - y, ord=1))
        print('Minimum distance found for ', songID.split("\\")[-1], ": ", dist)
        compare_result[songID] = dist

    matched_song = min(compare_result, key=compare_result.get)

    finish = time.time()
    print('Running time: %s Seconds' % (finish-start))
    print('The song matched is: ', matched_song)
    if compare_result[matched_song] >= 0.5:
        matched_song = 'music_base\\None' 
    act(matched_song.split("\\")[-1])
