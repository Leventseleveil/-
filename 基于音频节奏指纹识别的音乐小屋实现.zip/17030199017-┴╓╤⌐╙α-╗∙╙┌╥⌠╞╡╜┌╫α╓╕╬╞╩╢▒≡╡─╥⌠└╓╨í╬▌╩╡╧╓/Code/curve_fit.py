import matplotlib.pyplot as plt
from scipy import optimize
import numpy as np

def func(x, k):
    return k * x

x = np.array([1.68, 3.40, 3.51, 5.45, 11.1, 11.7])
y = np.array([0.765, 1.477, 1.59, 2.527, 5.236, 5.836])

popt, pcov = optimize.curve_fit(func, x, y)
k = popt[0]
print("The funtion relation is: y = %fx" % k)
yvals = func(x, k)

plot1 = plt.plot(x, y, '*', label = 'original values')
plot2 = plt.plot(x, yvals, 'r', label = 'curve_fit values')
plt.xlabel('SongSize(MB)/SongDuration')
plt.ylabel('RecognitionTime(s)')
plt.legend(loc = 4) #将图例置于右下角
plt.title('The relationship between RecognitionTime and SongSize')
plt.show()
plt.savefig('p4.png')